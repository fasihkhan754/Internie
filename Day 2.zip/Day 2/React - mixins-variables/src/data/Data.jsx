export const carddata = [
  { name: "Accelerometer data (iphone 14) -1 year", price: "$3000" },
  {
    name: "Accelerometer data (iphone 14) -1 year + ICD recordings (Medtronic) - 6 months",
    price: "$5000",
  },
  { name: "Accelerometer data (iphone 14) -1 year", price: "$3000" },
];
export const iconsdata = [
    { name: "Home", icon: "$3000" },
    {
      name: "Accelerometer data (iphone 14) -1 year + ICD recordings (Medtronic) - 6 months",
      price: "$5000",
    },
    { name: "Accelerometer data (iphone 14) -1 year", price: "$3000" },
  ];