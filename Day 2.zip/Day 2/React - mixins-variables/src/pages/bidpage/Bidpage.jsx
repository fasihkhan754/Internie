import React from "react";
import "./Bidpage.scss";
import { carddata } from "../../data/Data";

export const Bidpage = () => {
  return (
    <div className="bids__page__center">
      <h4> Bids</h4>
      {carddata.map((hcard)=>(
      <div className="bids__page__center__card">
        <div className="bids__page__center__card__left">
          {hcard.name}
          <br />
          <br />
          <b>{hcard.price}</b>
        </div>
        <div className="bids__page__center__card__right">
          <button>Assign user</button>
          <button>Customise</button>
          <button>Add Data measures</button>
        </div>
      </div>
      ))}
     
    </div>
  );
};
