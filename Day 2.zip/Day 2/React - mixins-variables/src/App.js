import logo from "./logo.svg";
import "./App.css";
import { Header } from "./components/header/Header";
import { Bidpage } from "./pages/bidpage/Bidpage";
import { Footer } from "./components/footer/Footer";

function App() {
  return (
    <div className="App">
      <Header />
      <Bidpage />
      <Footer />
    </div>
  );
}

export default App;
