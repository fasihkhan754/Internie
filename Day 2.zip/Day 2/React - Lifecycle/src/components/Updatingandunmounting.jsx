import React from "react";
class Updatingandunmounting extends React.Component {
  constructor(props) {
    console.log("inside constructor..");
    super(props);
    this.state = {
      name: "Fasih",
    };
  }
  static getDerivedStateFromProps(props, state) {
    console.log("inside getDerivedDstateFromProps...");

    return null;
  }
  componentDidMount() {
    console.log("inside ComponentDidMount...");
    this.setState({
      name: "Fasih",
    });
  }
  shouldComponentUpdate() {
    console.log("inside shouldComponentUpdate..");
    return true;
  }
  getSnapshotBeforeUpdate(prevProps, prevState) {
    console.log("inside getSnapshotBeforeBeforeUpdate...");
    console.log("prevstate:", prevState);
    return prevState;
  }
  componentDidUpdate(prevProps, prevState, snapshot) {
    console.log("inside ComponentDidUpdate...");
    console.log("snapshot: ", snapshot);
  }
  componentWillUnmount() {
    //remove event listeners
    //clear timeouts
  }
  render() {
    console.log("inside render...");
    return (
      <div className="">
        <p>my name is:{this.state.name}</p>
      </div>
    );
  }
}

export default Updatingandunmounting;
