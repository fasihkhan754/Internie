import React from "react";

class Classcomponent extends React.Component {
  constructor() {
    console.log("inside constructor..");
    super();
    this.state = {
      products: [],
    };
  }
  static getDerivedStateFromProps(props, state) {
    console.log("inside getDerivedDstateFromProps...");
    console.log("state is", state);
    console.log("props are: ", props);
    return {
      fname: props.defaultname,
    };
  }
  componentDidMount() {
    console.log("inside componentDidMount...");
    fetch("https://fakestoreapi.com/products")
      .then((res) => res.json())
      .then((json) => this.setState({
        products:json
      }))
  }
  render() {
    console.log("inside render...");
    console.log('products are: ', this.state.products);
    return (
      <div>
        <p>my name is {this.state.fname}</p>
      </div>
    );
  }
}

export default Classcomponent;
