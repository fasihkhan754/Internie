import logo from "./logo.svg";
import "./App.css";
import Classcomponent from "./components/Classcomponent";
import Updatingandunmounting from "./components/Updatingandunmounting";
import { Counter } from "./components/Counter";

function App() {
  return (
    <div className="App">
      <h1>lets understand lifecycle</h1>
      {/* <Classcomponent defaultname="Fasih" /> */}

      <Updatingandunmounting />
      {/* <Counter />*/}
    </div>
  );
}

export default App;
